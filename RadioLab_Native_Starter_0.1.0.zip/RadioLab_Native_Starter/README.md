# RadioLab Native — starter 0.1

Proyecto fuente inicial para Android Studio. **No es un APK compilado ni una versión probada en el Motorola.**

## Objetivo
- APK nativa con interfaz Compose oscura, estilo limpio.
- Sondeo visible objetivo: cada 2 s, sin prometer que el módem entregue datos nuevos a esa frecuencia.
- NetMonster Core para procesamiento/detección de tipo de red.
- Permisos de ubicación precisa y estado telefónico solicitados en tiempo de ejecución.
- Sin root obligatorio, sin cambios de módem/firmware ni escritura de parámetros de radio.

## Compatibilidad: qué se verificó
- NetMonster Core existe en Maven Central como `app.netmonster:core:1.3.0` y declara licencia Apache-2.0.
- Su README documenta `NetMonsterFactory.get(context)`, `getCells()` y `getNetworkType(subscriptionId)`.
- Android documenta `TelephonyManager.requestCellInfoUpdate()` desde API 29 y requiere `ACCESS_FINE_LOCATION`. Las actualizaciones están limitadas por el sistema y no están garantizadas.
- El proyecto usa `compileSdk = 36` y `targetSdk = 35` para mantener una base estable mientras el SDK 37/Android 17 y la ROM del dispositivo requieren validación específica.
- **No se pudo compilar en este entorno** porque no hay Android SDK/Gradle instalado. No se afirma compatibilidad probada con Android 17, Evolution X ni el módem del XT2301-4.

## Abrir y compilar
1. Descomprimí el ZIP.
2. Abrí la carpeta `RadioLab_Native_Starter` en Android Studio.
3. Instalá Android SDK Platform 36 y un JDK compatible con Android Gradle Plugin 8.9.2 (JDK 17).
4. Esperá la sincronización de Gradle.
5. Compilá desde **Build > Build APK(s)**.

Si Gradle informa que `app.netmonster:core:1.3.0` no resuelve, comprobá Maven Central y la conexión de Gradle.

## Prueba inicial en el teléfono
1. Instalá el APK de debug que genere Android Studio.
2. Concedé ubicación precisa y permiso de teléfono cuando se soliciten.
3. Abrí RadioLab y dejalo en primer plano.
4. Compará la celda/tecnología que muestre con NetMonster. Registrá también si aparece LTE-A/NR NSA.
5. Enviá captura de la pantalla y, si falla, el error de compilación o Logcat, ocultando IMEI/IMSI/ICCID y otros identificadores.

## Limitaciones intencionales
- Android puede devolver `CellInfo` almacenado en caché o limitar las solicitudes; se muestra la hora del último resultado recibido.
- Las celdas vecinas no deben confundirse con la celda servidora. La pantalla etiqueta el estado de registro cuando Android lo informa.
- La detección de LTE-CA y NSA depende de las fuentes que el fabricante expone. NetMonster Core también documenta que algunos detectores son estimaciones y pueden tener falsos positivos.
- Esta primera base es un esqueleto funcional de telemetría, no un reemplazo completo de NetMonster ni un APK validado en el dispositivo.

## Licencia
NetMonster Core se distribuye bajo Apache License 2.0. Este proyecto inicial no incluye ni redistribuye su código fuente.


## RadioLab Native 0.2.0 — NetMonster Core

Esta versión agrega la dependencia oficial `app.netmonster:core:1.3.0` y consulta
`NetMonsterFactory` fuera del hilo principal para mostrar el tipo de red inferido por
Core y la cantidad de celdas que consigue combinar. La lectura Android nativa queda
como respaldo; si Core falla, la app sigue mostrando las celdas nativas.

**Límites importantes:** LTE-A/CA y NR NSA son detecciones que dependen de las fuentes
que entregue la ROM/módem y algunas pueden ser inferidas. Esta integración no cambia
firmware ni requiere root. No promete recuperar RSSNR si el sistema devuelve un valor
inválido; eso debe verificarse en el dispositivo con el APK compilado.
