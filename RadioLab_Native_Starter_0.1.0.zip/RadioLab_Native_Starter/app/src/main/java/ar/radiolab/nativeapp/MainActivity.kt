package ar.radiolab.nativeapp

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.CellInfo
import android.telephony.CellInfoGsm
import android.telephony.CellInfoLte
import android.telephony.CellInfoNr
import android.telephony.CellInfoTdscdma
import android.telephony.CellInfoWcdma
import android.telephony.TelephonyManager
import android.telephony.SubscriptionManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import app.netmonster.core.factory.NetMonsterFactory

private val Bg = Color(0xFF070B12)
private val Panel = Color(0xFF111A27)
private val Accent = Color(0xFF8BAAFF)
private val Muted = Color(0xFF9AA9BF)

data class RadioSnapshot(
    val operator: String = "—",
    val network: String = "Sin datos",
    val headline: String = "Esperando permiso de telefonía",
    val details: List<String> = emptyList(),
    val coreType: String = "No consultado",
    val updatedAt: String = "—",
    val warning: String = "Los datos pueden estar almacenados en caché."
)

class MainActivity : ComponentActivity() {
    private var pollJob: Job? = null
    private val snapshot = mutableStateOf(RadioSnapshot())
    private val polling = mutableStateOf(true)
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        if (hasPermissions()) startPolling() else {
            snapshot.value = RadioSnapshot(
                headline = "Faltan permisos",
                warning = "Concedé ubicación precisa y estado del teléfono para consultar las celdas."
            )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = Bg, surface = Panel, primary = Accent,
                onBackground = Color(0xFFF2F5FB), onSurface = Color(0xFFF2F5FB)
            )) {
                Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
                    RadioLabScreen(
                        snapshot = snapshot.value,
                        polling = polling.value,
                        onTogglePolling = { enabled ->
                            polling.value = enabled
                            if (enabled) startPolling() else stopPolling()
                        },
                        onRefresh = { refreshOnce() },
                        onGrantPermissions = {
                            permissionLauncher.launch(arrayOf(
                                Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.READ_PHONE_STATE
                            ))
                        }
                    )
                }
            }
        }
        if (hasPermissions()) startPolling()
        else snapshot.value = RadioSnapshot(
            headline = "Permisos necesarios",
            warning = "Tocá «Conceder permisos» para habilitar el diagnóstico local."
        )
    }

    private fun hasPermissions(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
        ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED

    private fun stopPolling() {
        pollJob?.cancel()
        pollJob = null
    }

    private fun startPolling() {
        if (!hasPermissions()) return
        stopPolling()
        pollJob = lifecycleScope.launch {
            while (isActive) {
                if (polling.value) refreshOnce()
                delay(2_000L)
            }
        }
    }

    private fun refreshOnce() {
        if (!hasPermissions()) return
        lifecycleScope.launch {
            try {
                val telephonyBase = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
                val subId = runCatching { SubscriptionManager.getDefaultDataSubscriptionId() }
                    .getOrDefault(SubscriptionManager.INVALID_SUBSCRIPTION_ID)
                val telephony = if (subId != SubscriptionManager.INVALID_SUBSCRIPTION_ID) {
                    runCatching { telephonyBase.createForSubscriptionId(subId) }.getOrDefault(telephonyBase)
                } else telephonyBase

                val operator = telephony.networkOperatorName.takeIf { it.isNotBlank() } ?: "Operador no informado"
                val network = networkLabel(telephony.dataNetworkType)
                val cells = runCatching { telephony.allCellInfo.orEmpty() }.getOrDefault(emptyList())
                val rendered = cells.mapNotNull { renderCell(it) }
                val registered = cells.firstOrNull { it.isRegistered }
                val head = registered?.let { renderCell(it) } ?: "Android no marcó una celda servidora"
                val core = runCatching {
                    NetMonsterFactory.get(applicationContext).getNetworkType(subId).toString()
                }.getOrElse { "No disponible: ${it.javaClass.simpleName}" }
                val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
                snapshot.value = RadioSnapshot(
                    operator = operator,
                    network = network,
                    headline = head,
                    details = rendered,
                    coreType = core,
                    updatedAt = time,
                    warning = "Actualización solicitada cada 2 s. Android puede limitarla y devolver datos antiguos."
                )

                // Solicitud explícita de una nueva lectura. Android no garantiza respuesta a cada llamada.
                runCatching {
                    telephony.requestCellInfoUpdate(mainExecutor, object : TelephonyManager.CellInfoCallback() {
                        override fun onCellInfo(cellsUpdate: MutableList<CellInfo>) {
                            val updateTime = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
                            val newRendered = cellsUpdate.mapNotNull { renderCell(it) }
                            val newServing = cellsUpdate.firstOrNull { it.isRegistered }?.let { renderCell(it) }
                                ?: "Android no marcó una celda servidora"
                            snapshot.value = snapshot.value.copy(
                                headline = newServing,
                                details = newRendered,
                                updatedAt = updateTime,
                                warning = "Respuesta de requestCellInfoUpdate. La frecuencia real depende de Android y del módem."
                            )
                        }
                        override fun onError(errorCode: Int, detail: Throwable?) {
                            snapshot.value = snapshot.value.copy(
                                warning = "Android no entregó una lectura nueva (código $errorCode). Se conserva la última lectura."
                            )
                        }
                    })
                }
            } catch (e: Exception) {
                snapshot.value = snapshot.value.copy(
                    headline = "Error al consultar telefonía",
                    warning = "${e.javaClass.simpleName}: ${e.message ?: "sin detalle"}"
                )
            }
        }
    }

    private fun networkLabel(type: Int): String = when (type) {
        TelephonyManager.NETWORK_TYPE_LTE -> "LTE"
        TelephonyManager.NETWORK_TYPE_NR -> "NR / 5G"
        TelephonyManager.NETWORK_TYPE_HSPAP -> "HSPA+"
        TelephonyManager.NETWORK_TYPE_UMTS -> "UMTS / 3G"
        TelephonyManager.NETWORK_TYPE_GSM -> "GSM / 2G"
        TelephonyManager.NETWORK_TYPE_EDGE -> "EDGE / 2G"
        TelephonyManager.NETWORK_TYPE_UNKNOWN -> "Desconocido"
        else -> "Tipo $type"
    }

    private fun renderCell(cell: CellInfo): String? {
        val registered = if (cell.isRegistered) "SERVIDORA" else "detectada"
        return when (cell) {
            is CellInfoLte -> {
                val id = cell.cellIdentity
                val sig = cell.cellSignalStrength
                "LTE · $registered · banda ${id.bands.joinToString().ifBlank { "—" }} · EARFCN ${id.earfcn} · PCI ${id.pci} · RSRP ${sig.rsrp} dBm · RSRQ ${sig.rsrq} dB · RSSNR ${sig.rssnr}"
            }
            is CellInfoNr -> {
                val id = cell.cellIdentity
                val sig = cell.cellSignalStrength
                "NR · $registered · banda ${id.nrarfcn} NR-ARFCN · PCI ${id.pci} · SS-RSRP ${sig.ssRsrp} dBm · SS-RSRQ ${sig.ssRsrq} dB · SS-SINR ${sig.ssSinr}"
            }
            is CellInfoWcdma -> "WCDMA · $registered · PSC ${cell.cellIdentity.psc} · RSCP ${cell.cellSignalStrength.dbm} dBm"
            is CellInfoGsm -> "GSM · $registered · CID ${cell.cellIdentity.cid} · señal ${cell.cellSignalStrength.dbm} dBm"
            is CellInfoTdscdma -> "TD-SCDMA · $registered · señal ${cell.cellSignalStrength.dbm} dBm"
            else -> null
        }
    }

    override fun onDestroy() {
        stopPolling()
        super.onDestroy()
    }
}

@Composable
private fun RadioLabScreen(
    snapshot: RadioSnapshot,
    polling: Boolean,
    onTogglePolling: (Boolean) -> Unit,
    onRefresh: () -> Unit,
    onGrantPermissions: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().background(Bg).padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(Modifier.height(12.dp))
            Text("KERNELSU-OPTIONAL · NATIVO", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text("RadioLab", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
            Text("Tu red, bajo la lupa.", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Accent)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(24.dp)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("CENTRO DE DIAGNÓSTICO", color = Muted, fontWeight = FontWeight.Bold)
                    Text(snapshot.headline, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    Text("Operador: ${snapshot.operator}  ·  Red: ${snapshot.network}")
                    Text("Última lectura: ${snapshot.updatedAt}", color = Muted)
                    Text(snapshot.warning, color = Color(0xFFFFCF7A), fontSize = 12.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Actualizar objetivo: 2 s", modifier = Modifier.weight(1f), color = Muted)
                        Switch(checked = polling, onCheckedChange = onTogglePolling)
                    }
                    Button(onClick = onRefresh, modifier = Modifier.fillMaxWidth()) { Text("Leer ahora") }
                    Button(onClick = onGrantPermissions, modifier = Modifier.fillMaxWidth()) { Text("Conceder permisos") }
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("NETMONSTER CORE", color = Accent, fontWeight = FontWeight.Bold)
                    Text(snapshot.coreType)
                    Text("La detección de LTE-A/NSA depende de los datos que exponga la ROM.", color = Muted, fontSize = 12.sp)
                }
            }
        }
        item {
            Text("Celdas reportadas por Android", fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Text("La etiqueta SERVIDORA corresponde a isRegistered; las demás pueden ser vecinas.", color = Muted, fontSize = 12.sp)
        }
        if (snapshot.details.isEmpty()) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                    Text("Todavía no hay información de celdas disponible.", Modifier.padding(18.dp), color = Muted)
                }
            }
        } else {
            items(snapshot.details) { cell ->
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                    Text(cell, Modifier.padding(16.dp), fontSize = 14.sp)
                }
            }
        }
        item {
            Text("Privacidad: el diagnóstico se procesa localmente. No se envían datos a ningún servidor.", color = Muted, fontSize = 12.sp)
            Spacer(Modifier.height(20.dp))
        }
    }
}
